package banalytics;

public class BanalyserException extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

}
